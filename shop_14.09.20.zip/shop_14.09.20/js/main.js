$(document).ready(function(){
	$('.slider').slick({
		slidesToShow:1,
		slidesToScroll: 1,
		variableWidth:true,
		arrows: false,
		dots: true
	});
});