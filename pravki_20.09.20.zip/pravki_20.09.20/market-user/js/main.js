$(document).ready(function(){
	$('.slider').slick({
		slidesToShow:1,
		slidesToScroll: 1,
		variableWidth:true,
		infinite: false,
		arrows: false,
		dots: true
	});
});